# Week 1 – Student Performance Analysis

## Objective
Explore the Students Performance in Exams dataset, define an analytical problem, inspect data quality, summarize scores, and propose an analysis strategy.

## Project structure
```text
Week1_Student_Performance_Analysis/
├── Week1_Data_Exploration_Report.docx
├── README.md
├── requirements.txt
├── data/
│   └── StudentsPerformance.csv   # Add the downloaded dataset here
└── notebooks/
    └── Week1_Student_Performance_EDA.ipynb
```

## Dataset
Download `StudentsPerformance.csv` from:
https://www.kaggle.com/datasets/spscientist/students-performance-in-exams

Save the CSV in the `data` folder. Do not rename its columns unless you also update the notebook.

## Run on Windows
```powershell
cd path\to\Week1_Student_Performance_Analysis
python -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
jupyter notebook
```
If PowerShell blocks activation, use:
```powershell
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe -m notebook
```
Open `notebooks/Week1_Student_Performance_EDA.ipynb` and run all cells. The notebook expects the CSV at `data/StudentsPerformance.csv`.

## Problem statement
Explore how mathematics, reading and writing scores vary and whether they are associated with test-preparation completion and selected student-group descriptors. The analysis is descriptive and does not establish causation.

## Submission checklist
- [ ] Replace cover-page placeholders with your details.
- [ ] Add the original CSV to `data/`.
- [ ] Run the notebook from top to bottom.
- [ ] Review actual missing-value, duplicate and range-check outputs.
- [ ] Add any important findings from your run to the report.
- [ ] Upload the report, notebook, README and dataset (only if redistribution is permitted) to GitHub.
